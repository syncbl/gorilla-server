﻿using System;
using System.Text;
using System.ComponentModel;
using System.Runtime.InteropServices;

namespace LicenseSigner
{
    static class LicenseSigner
    {
        private const string _licenseSubject = "SmartSource Licensing";

        public static string Sign(string input)
        {
            // Variables.
            Byte[] pbMessage = null;
            Int32 cbMessage = 0;
            IntPtr[] messageArray = null;
            Int32[] messageSizeArray = null;
            IntPtr hStoreHandle = IntPtr.Zero;
            IntPtr pSignerCert = IntPtr.Zero;
            Crypto.CRYPT_SIGN_MESSAGE_PARA sigParams;
            Boolean res = false;
            Int32 cbSignedMessageBlob = 0;
            Byte[] pbSignedMessageBlob = null;
            string signedInput = "";

            try
            {
                // Size of message.
                //
                pbMessage = (new UnicodeEncoding()).GetBytes(input);
                cbMessage = pbMessage.Length;

                // Create the MessageArray and the MessageSizeArray.
                //        
                messageArray = new IntPtr[1];
                messageArray[0] = Marshal.AllocHGlobal(pbMessage.Length);
                Marshal.Copy(pbMessage, 0, messageArray[0], pbMessage.Length);
                messageSizeArray = new Int32[1];
                messageSizeArray[0] = cbMessage;

                // Open a certificate store.
                //
                hStoreHandle = Crypto.CertOpenStore(
                  Crypto.CERT_STORE_PROV_SYSTEM,
                  0,
                  IntPtr.Zero,
                  Crypto.CERT_SYSTEM_STORE_CURRENT_USER,
                  Crypto.CERT_TRUSTED_ROOT_STORE_NAME
                );
                if (hStoreHandle == IntPtr.Zero)
                {
                    throw new Exception("CertOpenStore error", new Win32Exception(Marshal.GetLastWin32Error()));
                }

                // Get a pointer to the signer's certificate.
                // This certificate must have access to the signer's private key.
                pSignerCert = Crypto.CertFindCertificateInStore(
                  hStoreHandle,
                  Crypto.MY_TYPE,
                  0,
                  Crypto.CERT_FIND_SUBJECT_STR,
                  _licenseSubject,
                  IntPtr.Zero
                );
                if (pSignerCert == IntPtr.Zero)
                {
                    throw new Exception("CertFindCertificateInStore error", new Win32Exception(Marshal.GetLastWin32Error()));
                }

                sigParams = new Crypto.CRYPT_SIGN_MESSAGE_PARA();
                sigParams.cbSize = Marshal.SizeOf(sigParams);
                sigParams.HashAlgorithm.pszObjId = Crypto.szOID_RSA_MD5;
                sigParams.pSigningCert = pSignerCert;
                sigParams.dwMsgEncodingType = Crypto.X509_ASN_ENCODING | Crypto.PKCS_7_ASN_ENCODING;
                sigParams.cMsgCert = 1;
                GCHandle gcHandle = GCHandle.Alloc(pSignerCert, GCHandleType.Pinned);
                sigParams.rgpMsgCert = gcHandle.AddrOfPinnedObject();
                gcHandle.Free();

                // With two calls to CryptSignMessage, sign the message.
                // First, get the size of the output signed BLOB.
                //
                res = Crypto.CryptSignMessage(
                  ref sigParams,      // Signature parameters
                  false,          // Not detached
                  1,            // Number of messages
                  messageArray,      // Messages to be signed
                  messageSizeArray,    // Size of messages
                  null,          // Buffer for signed message
                  ref cbSignedMessageBlob  // Size of buffer
                );
                if (res == false)
                {
                    throw new Exception("CryptSignMessage error", new Win32Exception(Marshal.GetLastWin32Error()));
                }

                // Allocate memory for the signed BLOB.
                //
                pbSignedMessageBlob = new Byte[cbSignedMessageBlob];

                // Get the SignedMessageBlob.
                //
                res = Crypto.CryptSignMessage(
                  ref sigParams,      // Signature parameters
                  false,          // Not detached
                  1,            // Number of messages
                  messageArray,      // Messages to be signed
                  messageSizeArray,    // Size of messages
                  pbSignedMessageBlob,  // Buffer for signed message
                  ref cbSignedMessageBlob // Size of buffer
                );
                if (res == false)
                {
                    throw new Exception("CryptSignMessage error", new Win32Exception(Marshal.GetLastWin32Error()));
                }

                // pbSignedMessageBlob points to the signed BLOB. Return the signature.
                signedInput = SmartSourceBase64Encode(pbSignedMessageBlob);

            }
            finally
            {
                // Clean up and free memory.
                //
                if (messageArray[0] != IntPtr.Zero)
                {
                    Marshal.FreeHGlobal(messageArray[0]);
                }
                if (pSignerCert != IntPtr.Zero)
                {
                    Crypto.CertFreeCertificateContext(pSignerCert);
                }
                if (hStoreHandle != IntPtr.Zero)
                {
                    Crypto.CertCloseStore(
                      hStoreHandle,
                      Crypto.CERT_CLOSE_STORE_CHECK_FLAG
                    );
                }
            }

            return signedInput;
        }

        private static string SmartSourceBase64Encode(byte[] input)
        {
            string base64Encoded = Convert.ToBase64String(input);
            string smartSourceBase64Encoded = "";
            char[] base64LookupTable = new char[64]
                  {  'A','B','C','D','E','F','G','H','I','J','K','L','M',
                    'N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
                    'a','b','c','d','e','f','g','h','i','j','k','l','m',
                    'n','o','p','q','r','s','t','u','v','w','x','y','z',
                    '0','1','2','3','4','5','6','7','8','9','+','/'};
            char[] smartSourceBase64LookupTable = new char[64]
                  {  '+','-','0','1','2','3','4','5','6','7','8','9',
                    'A','B','C','D','E','F','G','H','I','J','K','L','M',
                    'N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
                    'a','b','c','d','e','f','g','h','i','j','k','l','m',
                    'n','o','p','q','r','s','t','u','v','w','x','y','z'};
            for (int i = 0; i < base64Encoded.Length; i++)
            {
                int index = new string(base64LookupTable).IndexOf(base64Encoded[i]);
                if (index != -1)
                {
                    smartSourceBase64Encoded += smartSourceBase64LookupTable[index];
                }
            }

            return smartSourceBase64Encoded;
        }
    }
}
