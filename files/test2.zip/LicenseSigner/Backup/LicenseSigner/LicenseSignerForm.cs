﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LicenseSigner
{
    public partial class LicenseSignerForm : Form
    {
        public LicenseSignerForm()
        {
            InitializeComponent();
        }

        private void signButton_Click(object sender, EventArgs e)
        {
            try
            {
                signedTextBox.Text = LicenseSigner.Sign(licenseTextBox.Text);
            }
            catch (Exception ex)
            {
                // Any errors? Show them.
                //
                if (ex.InnerException == null)
                {
                    MessageBox.Show(ex.Message);
                }
                else
                {
                    MessageBox.Show(ex.Message + "\n" + ex.InnerException.Message);
                }
            }
        }

        private void licenseTextBox_TextChanged(object sender, EventArgs e)
        {
            signedTextBox.Text = string.Empty;
        }
    }
}
