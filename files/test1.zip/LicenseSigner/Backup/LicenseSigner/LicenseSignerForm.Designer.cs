﻿namespace LicenseSigner
{
    partial class LicenseSignerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.licenseTextBox = new System.Windows.Forms.TextBox();
            this.enterLicenseLabel = new System.Windows.Forms.Label();
            this.signedTextBox = new System.Windows.Forms.TextBox();
            this.signButton = new System.Windows.Forms.Button();
            this.signedLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // licenseTextBox
            // 
            this.licenseTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.licenseTextBox.Location = new System.Drawing.Point(12, 30);
            this.licenseTextBox.Multiline = true;
            this.licenseTextBox.Name = "licenseTextBox";
            this.licenseTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.licenseTextBox.Size = new System.Drawing.Size(771, 233);
            this.licenseTextBox.TabIndex = 0;
            this.licenseTextBox.TextChanged += new System.EventHandler(this.licenseTextBox_TextChanged);
            // 
            // enterLicenseLabel
            // 
            this.enterLicenseLabel.AutoSize = true;
            this.enterLicenseLabel.Location = new System.Drawing.Point(12, 14);
            this.enterLicenseLabel.Name = "enterLicenseLabel";
            this.enterLicenseLabel.Size = new System.Drawing.Size(114, 13);
            this.enterLicenseLabel.TabIndex = 1;
            this.enterLicenseLabel.Text = "Enter the license XML:";
            // 
            // signedTextBox
            // 
            this.signedTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.signedTextBox.Location = new System.Drawing.Point(15, 333);
            this.signedTextBox.Multiline = true;
            this.signedTextBox.Name = "signedTextBox";
            this.signedTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.signedTextBox.Size = new System.Drawing.Size(771, 233);
            this.signedTextBox.TabIndex = 2;
            // 
            // signButton
            // 
            this.signButton.Location = new System.Drawing.Point(12, 279);
            this.signButton.Name = "signButton";
            this.signButton.Size = new System.Drawing.Size(114, 23);
            this.signButton.TabIndex = 3;
            this.signButton.Text = "Sign";
            this.signButton.UseVisualStyleBackColor = true;
            this.signButton.Click += new System.EventHandler(this.signButton_Click);
            // 
            // signedLabel
            // 
            this.signedLabel.AutoSize = true;
            this.signedLabel.Location = new System.Drawing.Point(12, 317);
            this.signedLabel.Name = "signedLabel";
            this.signedLabel.Size = new System.Drawing.Size(43, 13);
            this.signedLabel.TabIndex = 4;
            this.signedLabel.Text = "Signed:";
            // 
            // LicenseSignerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(797, 578);
            this.Controls.Add(this.signedLabel);
            this.Controls.Add(this.signButton);
            this.Controls.Add(this.signedTextBox);
            this.Controls.Add(this.enterLicenseLabel);
            this.Controls.Add(this.licenseTextBox);
            this.Name = "LicenseSignerForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SmartSource License Signer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox licenseTextBox;
        private System.Windows.Forms.Label enterLicenseLabel;
        private System.Windows.Forms.TextBox signedTextBox;
        private System.Windows.Forms.Button signButton;
        private System.Windows.Forms.Label signedLabel;
    }
}

